import json
# from gs import *
from datetime import *
from settings import *
from instruments import *
from logs import *
import asyncio
from fbase import *
from mt45 import *

try:
    running_trades = loadSettings("running trades.json")
except (FileNotFoundError, json.decoder.JSONDecodeError):
    running_trades = {}
    saveSettings("running trades.json", running_trades)
except Exception as err:
    saveFailedExe("init in handle_results", "init", str(err), "")


def save_successful_trades(results_data):
    for_ref = (results_data)
    try:
        try:
            meta_account_data = results_data['trade_data']['meta_account_data']
            broker = meta_account_data['broker']
            account_login = meta_account_data['login']
            message = results_data["message"]
            trade_data = results_data["trade_data"]
            app = "Telegram"
            sub_Number = results_data["phone_number"]
            channel = message.chat.title
            channel_id = message.chat.id
            channel_url = ""
            message_url = message.link
            msg_txt = message.text
            if type(results_data['trade_data']['trade_meta']) is float:
                risk_to_reward = ""
                trade_profits = ""
                Win_or_Loss = ""
                now_entry = results_data['trade_data']['trade_meta']
            else:
                trade_data["entry"]
                trade_profits = float(
                    results_data['trade_data']['trade_meta']['profit'])
                Win_or_Loss = "winning" if trade_profits > 0 else "lossing"
                now_entry = results_data['trade_data']['trade_meta']['openPrice']
                save_instruments_tick_value(
                    {"symbol": results_data['trade_data']['symbol'], "tick value": results_data['trade_data']['trade_meta']['currentTickValue']})

            cal_tp = [float(now_entry), float(trade_data["tp now"])]
            cal_tp = sorted(cal_tp, key=lambda x: float(x))
            cal_tp = cal_tp[1]-cal_tp[0]
            cal_sl = [float(now_entry), float(trade_data["sl"])]
            cal_sl = sorted(cal_sl, key=lambda x: float(x))
            cal_sl = cal_sl[1]-cal_sl[0]
            risk_to_reward = "Not specified" if trade_data[
                "sl"] == 0 or trade_data["tp now"] == 0 else cal_tp/cal_sl

            message_time = str(datetime.fromisoformat(str(message.date)).astimezone(
                timezone.utc).strftime('%Y-%m-%d %H:%M:%S'))
            g = [app, sub_Number, channel, channel_id, channel_url, message_time, message_url, msg_txt, broker, account_login, trade_data["results"]["positionId"], trade_data["symbol"], trade_data["market execution"],
                 trade_data["init_lot_size"], trade_data["lot_size"], trade_data["lot_size"], trade_data["entry"], trade_data["tp now"], trade_data["sl"], risk_to_reward, "running", "-", "-"]
            titl = ["App", "Sub Number", "Channel", "Channel Code", "Channel URL", "Message Timestamp", "Message URL", "Message", "Broker Name", "Metatrader Account ID", "Ticket Number",
                    "Symbol", "Market Execution", "Initial Lot Size", "Used Lot Size", "Current Lot Size", "Entry Price", "TP", "SL", "Risk To Reward", "Status", "Win or Loss", "Profits"]
            fire_data = {}
            for x in range(0, len(titl)-1):
                fire_data.update({titl[x]: g[x]})
            fire_data.update({"track": broker+"/"+account_login +
                              "/"+trade_data["results"]["positionId"]})
            save_running_trade([fire_data])

            row_meta = {"accounts": trade_data['accounts'], "value": fire_data}
            token = row_meta["accounts"]['token']
            key = row_meta["accounts"]['key']

            if token not in running_trades.keys():
                running_trades.update({token: {}})

            if key not in running_trades[token].keys():
                running_trades[token].update({key: []})

            running_trades[token][key].append(row_meta)
            saveSettings("running trades.json", running_trades)
        except Exception as e:
            print(str(e))

    except Exception as err:
        saveFailedExe("Save_successful_trades in handle_results",
                      "Save_successful_trades", str(err), for_ref)


def save_trade_results(results_data):
    for_ref = (results_data)
    try:
        if results_data['trade_data']['executed']:
            save_successful_trades(results_data)
        else:
            results_data = "\n-------------------------------------------------------------------\n" + \
                str(results_data)+"\n----------------------"
            saveLogD("Handle Failed results", results_data)
    except Exception as err:
        saveFailedExe("save_trade_results in handle_results",
                      "save_trade_results", str(err), for_ref)


async def trades_to_list():
    for_ref = ""
    try:
        k = []
        for x in running_trades:
            for j in running_trades[x].keys():
                for t in running_trades[x][j]:
                    k.append(t)
        print(k)
    except Exception as err:
        saveFailedExe("trades_to_list in handle_results",
                      "trades_to_list", str(err), for_ref)


def track_trades():
    for_ref = ""
    try:
        all_running_trades = loadSettings("running trades.json")
        for x in all_running_trades:
            for y in all_running_trades[x]:
                running = []
                complete = []
                for j in all_running_trades[x][y]:
                    if j['value']["Status"] == False:
                        continue
                    if j['value']["Status"] == "complete":
                        complete.append(j['value'])
                    else:
                        running.append(j)
                all_running_trades[x].update({y: running})
                save_running_trade(running)
                for t in complete:
                    save_complete_trade(t)
        saveSettings("running trades.json", all_running_trades)
    except Exception as err:
        saveFailedExe("track_trades in handle_results",
                      "track_trades", str(err), for_ref)


async def sort_trades():
    for_ref = ""
    try:
        try:
            await get_position_data()
        except Exception as err:
            print(str(err))
        track_trades()
    except Exception as err:
        saveFailedExe("sort_trades in handle_results",
                      "sort_trades", str(err), for_ref)

# track_trades()
