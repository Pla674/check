from cleantext import clean
from logs import *
import re
from datetime import date
from mt45 import *
import asyncio
from instruments import instruments, not_used_instruments
from instruments import *
# from googletrans import Translator

# translator = Translator()
inforTitles = "Chat Name\tMessage ID\tMessage\tTimestamp\tLink"
othName = ""


def getRealValues(txt, pat):
    for_ref = (txt, pat)
    try:
        j = 0
        for x in pat:
            if len(re.findall(x[0], txt)) > 0:
                num = re.findall(x[0], txt)
                num = num[0]
                num = re.sub(x[1], " ", num)
                num = replaceAll(num, "  ", " ")
                return num.strip()
            j = j + 1
    except Exception as err:
        saveFailedExe("getRealValues in support",
                      "getRealValues", str(err), for_ref)


def pop_dict(key1, dictionary):
    for_ref = (key1, dictionary)
    try:
        if key1 in dictionary:
            popped = dictionary.pop(key1)
            popped = {key1: popped}
            return [popped, dictionary]
        else:
            return False
    except Exception as err:
        saveFailedExe("pop_dict in support", "pop_dict", str(err), for_ref)


def removeUrl(txt):
    for_ref = txt
    try:
        rawD = txt
        txt = re.sub(r"https //\S+|http //\S+|http\S+", " ", txt)
        saveLogD("Re Version.txt", rawD+"##########################################\n"+txt.strip() +
                 "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n", "a")
        return txt.strip()
    except Exception as err:
        saveFailedExe("removeUrl in support", "removeUrl", str(err), for_ref)


def getTP(txt):
    for_ref = txt
    try:
        tpPattern = [[r"\d?take ?profits?\.? ?\d open", r"\d?take ?profits?\.? ?\d"],
                     [r"\d?take ?profits?\.? ?open", r"\d?take ?profits?\.? ?"],
                     [r"\d?t\.?p\.? ?\d? open", r"\d?t\.?p\.? ?\d?"],
                     [r"\d?take ?profits?\.? ?\d \d+\.\d+",
                      r"\d?take ?profits?\.? ?\d"],
                     [r"\d?take ?profits?\.? ?\d \d+",
                      r"\d?take ?profits?\.? ?\d? ?\d"],
                     [r"\d?take ?profits?\.? ?\d+\.\d+", r"\d?take ?profits?\.? ?"],
                     [r"\d?take ?profits?\.? ?\d+", r"\d?take ?profits?\.? ?"],
                     [r"\d?t\.?p\.? ?\d \d+\.\d+", r"\d?t\.?p\.? ?\d"],
                     [r"\d?t\.?p\.? ?\d \d+", r"\d?t\.?p\.? ?\d"],
                     [r"\d?tp ?\d? ?\.{2,} ?\d+\.\d+",
                         r"\d?tp ?\d? ?\.{2,} ?"],
                     [r"\d?tp ?\d? ?\.{2,} ?\d+", r"\d?tp ?\d? ?\.{2,} ?"],
                     [r"\d?t\.?p\.? ?\d+\.\d+", r"\d?t\.?p\.? ?"],
                     [r"\d?t\.?p\.? ?\d+", r"\d?t\.?p\.? ?"],
                     [r"tp \.\d+\.\d+", r"tp \."],
                     [r"tp \.\d+", r"tp \."]]

        hha = re.findall(r"tp\.? ?\d \d+ \d+", txt)
        if len(hha) > 0:
            hha = hha[0].strip()
            hha = re.sub(r"tp\.? ?\d ", "", hha)
            hha = hha.split(" ")
            hha = ".".join(hha)
            hha = replaceAll(hha, "..", ".")
            return hha

        hha = re.findall(r"\dtp\.? \d+\.? \.?\d+", txt)
        if len(hha) > 0:
            hha = hha[0].strip()
            hha = re.sub(r"\dtp\.? ", "", hha)
            hha = hha.split(" ")
            hha = ".".join(hha)
            hha = replaceAll(hha, "..", ".")
            return hha

        check = re.findall(
            r"tp\.? ?\d? ?hit|tp\.? ?\d? ?smashe?d?|tp\.? ?\d? ?done|tp\.? ?\d? ?complete|tp ?\d ?\+?\d+\+? ?pips", txt)
        if len(check) > 0:
            saveLogD("Failed to get tp", str(for_ref))
            return
        return getRealValues(txt, tpPattern)
    except Exception as err:
        saveFailedExe("getTP in support", "getTP", str(err), for_ref)


def replaceAll(a, b, c):
    for_ref = (a, b, c)
    try:
        d = a.replace(b, c)
        while d != a:
            a = d
            d = a.replace(b, c)
        return d.strip()
    except Exception as err:
        saveFailedExe("replaceAll in support", "replaceAll", str(err), for_ref)


def isFloat(txt):
    for_ref = txt
    try:
        try:
            float(txt)
            return True
        except:
            return False
    except Exception as err:
        saveFailedExe("isFloat in support", "isFloat", str(err), for_ref)


def inndexf(list, item):
    for_ref = (list, item)
    try:
        try:
            return list.index(item)
        except:
            return -1
    except Exception as err:
        saveFailedExe("inndexf in support", "inndexf", str(err), for_ref)


def substring(txt, frm, t):
    for_ref = (txt, frm, t)
    try:
        return txt[frm:t:1]
    except Exception as err:
        saveFailedExe("substring in support", "substring", str(err), for_ref)

# def substring(txt,frm):
#    return txt[frm:]


async def getSymbol(txt):
    for_ref = txt
    try:
        distraction_string = "big"
        marEx = ["(?:buy|sell) stop limit", "(?:buy|sell) limit",
                 "(?:buy|sell) stop", "(?:buy|sell)"]
        txt = txt.casefold()
        symb = dict()
        j = txt
        symb.update({"gotit": False})
        if not symb["gotit"]:
            global instruments
            global not_used_instruments
            temp_not_used_symbols = {'0': not_used_instruments}
            all_symbols = {**instruments, **temp_not_used_symbols}
            for z in all_symbols.keys():
                for x in all_symbols[z]:
                    saveLogD("Shit", "\n"+str(x))
                    y = x["OtherName"].casefold()

                    i = 0
                    for g in marEx:
                        if i == 0:
                            f = r"\b"+re.escape(y+" ")+g+"\\b|\\b" + \
                                g+re.escape(" "+y)+"\\b"
                        else:
                            f = f+"|\\b"+re.escape(y+" ")+g+"\\b|\\b" + \
                                g+re.escape(" "+y)+"\\b"

                        f = f+"|\\b"+re.escape(y)+" "+distraction_string+" "+g + \
                            "\\b|\\b"+g+" "+distraction_string + \
                            " "+re.escape(y)+"\\b"

                        i = i + 1

                    if len(re.findall(f, txt)) > 0:
                        txt.replace(x["OtherName"].casefold(), " ")
                        txt = replaceAll(txt, "  ", " ")
                        symb.update({"gotit": True})
                        symb.update({"symbol": x["symbol"]})
                        account = await get_metatrader_account(x["OtherName"])
                        if account is False:
                            temp_infor = ""
                            temp_infor = "The input is : "+str(for_ref)
                            temp_infor = temp_infor + \
                                "\nThe account is : "+str(account)
                            saveLogD("Couldn't get symbol", str(temp_infor))
                            return
                        x.update({"accounts": account})
                        symb.update(x)
                        txt = replaceAll(replaceAll(txt.replace(
                            x["symbol"].casefold(), " "), "\n", " "), "  ", " ")
                        symb.update({"extra": txt})
                        trac = int(z) + 1
                        if str(trac) in all_symbols:
                            all_symbols[str(trac)].append(x)
                        else:
                            temp_simbols = {str(trac): [x]}
                            all_symbols = {**temp_simbols, **all_symbols}
                        # all_symbols[str(z)].remove(x)

                        all_symbols[z].remove(x)
                        not_used_instruments = all_symbols["0"]
                        all_symbols.pop("0")
                        instruments = all_symbols
                        saveSettings(
                            "mostly used instruments.json", instruments)
                        saveSettings("not used instruments.json",
                                     not_used_instruments)
                        return symb
                        if len(txt) > 0:
                            pass
                        break
            all_symbols = []
        if not symb["gotit"]:
            pass
        return symb
    except Exception as err:
        saveFailedExe("getSymbol in support", "getSymbol", str(err), for_ref)


def lastPosition(txt, nam):
    for_ref = (txt, nam)
    try:
        chars = ["*", "-", "/", "_", "  "]
        for x in chars:
            txt = replaceAll(txt, x, " ")

        for x in nam:
            if isinstance(x, list):
                j = re.findall(r""+x[0], txt)
                if len(j) >= 1:
                    return txt.rfind(j[len(j) - 1])
            elif isinstance(x, str):
                if (txt.rfind(x) >= 0):
                    return txt.rfind(x)
        return -1
    except Exception as err:
        saveFailedExe("lastPosition in support",
                      "lastPosition", str(err), for_ref)


def lastTPPosition(txt):
    for_ref = txt
    try:
        return lastPosition(txt, ["take profit", "takeprofit", ['\\d+tp'], "t.p.", "tp.", "tp"])
    except Exception as err:
        saveFailedExe("lastTPPosition in support",
                      "lastTPPosition", str(err), for_ref)


def lastSLPosition(txt):
    for_ref = txt
    try:
        return lastPosition(txt, ['stop loss', 'stoploss', 's.l', 'sl.', 'sl'])
    except Exception as err:
        saveFailedExe("lastSLPosition in support",
                      "lastSLPosition", str(err), for_ref)


def signalCleanUp(txt):
    for_ref = txt
    try:
        pattern = r"\d+ ?%|\d+ ?min\S+|\d+ ?days|\d+ ?members|\d+ ?people|\d+[+]\ ?pip\S|[+]\d+\ ?pip\S|\d+\ ?pip\S|first ?\d+ ?guy|\d+ ?year|\d+ ?follo\S"
        txt = re.sub(pattern, " ", txt)
        return txt
    except Exception as err:
        saveFailedExe("signalCleanUp in support",
                      "signalCleanUp", str(err), for_ref)


def getEntryPrice(txt):
    for_error = txt
    try:
        pric = ""
        txt = re.findall(
            r"\d+\.\d+ ?(?:-|~|/|_| ) ?\d+\.\d+|\d+\.\d+|\d+ ?(?:-|~|/|_| ) ?\d+|\d+", txt)
        if len(txt) > 0:
            txt = re.sub(r"(?:-|~|/|_)", ",", txt[0])

            if "," in txt:
                txt = txt.split(",")
                for x in range(0, len(txt)):
                    txt[x] = txt[x].strip()
                if len(txt[0]) > len(txt[1]):
                    txt[1] = txt[0][0:(-1 * len(txt[1]))]+txt[1]
                txt = str(txt)
                txt = replaceAll(txt, ",,", ",")
            return txt
        else:
            saveLogD("Could not get entry", str(for_error))
            return "current price"
    except Exception as err:
        saveFailedExe("getEntryPrice in support",
                      "getEntryPrice", str(err), for_ref)


def getEntry(txt):
    for_ref = txt
    try:
        pric = ''
        rawT = txt
        txt = re.sub(r"\bat\b", " ", txt)
        txt = re.sub(r"\bcmp\b", " ", txt)
        txt = re.sub(r"\bagain\b", " ", txt)
        txt = re.sub(r"\bfrom\b", " ", txt)
        txt = re.sub(r"\bstrong\b", " ", txt)
        txt = re.sub(r"\bzone\b", " ", txt)
        txt = re.sub(r"\bin\b", " ", txt)
        txt = re.sub(r"\bthe\b", " ", txt)
        txt = re.sub(r"\blimit\b", " ", txt)
        txt = re.sub(r"\bstop\b", " ", txt)
        txt = re.sub(r"\bbig\b", " ", txt)
        txt = re.sub(r"\b\d{2}/\b", " ", txt)
        txt = re.sub(r"\b"+re.escape(othName)+"\\b", " ", txt)
        txt = re.sub(r"@[A-Za-z][A-Za-z|_|0-9]+", " ", txt)
        txt = replaceAll(txt, "@", " ")
        txt = replaceAll(txt, "  ", " ")
        chec = [re.findall(r"entry (?:\d+\.\d+ ?(?:-|~|/|_| ) ?\d+\.\d+|\d+\.\d+|\d+ ?(?:-|~|/|_| ) ?\d+|\d+)", txt),
                re.findall(
                    r"(?:buy|sell) (?:\d+\.\d+ ?(?:-|~|/|_| ) ?\d+\.\d+|\d+\.\d+|\d+ ?(?:-|~|/|_| ) ?\d+|\d+)", txt),
                re.findall(
                    r"(?:buy|sell) now (?:\d+\.\d+ ?(?:-|~|/|_| ) ?\d+\.\d+|\d+\.\d+|\d+ ?(?:-|~|/|_| ) ?\d+|\d+)", txt),
                re.findall(r"(?:entry|buy|sell) now(?:`|\s$)|(?:buy|sell)", txt)]
        if len(chec[0]) > 0:
            pric = getEntryPrice(chec[0][0])
            saveLogD("success entry.txt", str(
                rawT+"\n"+str(chec[0])+"\n"+pric+"\n\n"), "a")
        elif len(chec[1]) > 0:
            pric = getEntryPrice(chec[1][0])
            saveLogD("success entry.txt", str(
                rawT+"\n"+str(chec[1])+"\n"+pric+"\n\n"), "a")
        elif len(chec[2]) > 0:
            pric = getEntryPrice(chec[2][0])
            saveLogD("success entry.txt", str(
                rawT+"\n"+str(chec[2])+"\n"+pric+"\n\n"), "a")
        elif len(chec[3]) > 0:
            pric = getEntryPrice(chec[3][0])
            saveLogD("success entry.txt", str(
                rawT+"\n"+str(chec[3])+"\n"+pric+"\n\n"), "a")
        else:
            saveLogD("shasha.txt", txt+"\n\n", "a")
        return pric
    except Exception as err:
        saveFailedExe("getEntry in support", "getEntry", str(err), for_ref)


def getSL(txt):
    for_ref = txt
    try:
        pla = re.findall(r"\d+\.\d+\.\d+", txt)
        while len(pla) > 0:
            g = pla[0]
            g = g.split(".")
            g.pop(0)
            g = ".".join(g)
            txt = replaceAll(txt, pla[0], g)
            pla = re.findall(r"\d+\.\d+\.\d+", txt)
        pla = [r"\d+%", "  "]
        for x in pla:
            txt = re.sub(x, " ", txt)
        chars = ["=", ",", "@", "_", "-", "at", "/", "(", ")", "  "]
        for x in chars:
            txt = replaceAll(txt, x, " ")

        txt = re.sub(r"stop ?loss|s\.l", "sl", txt)
        pla = re.findall(r"sl ?\.\d+", txt)
        if len(pla) > 0:
            pla = pla[0]
            txt = replaceAll(txt, pla, pla.replace(".", ""))
        txt = re.sub(r"\.{2,}", " ", txt)
        txt = replaceAll(txt, "  ", " ")

        # for a stop loss with a double but the double have a space instaded of a period
        pla = re.findall(r"sl ?\.? ?\d+\.? \d+", txt)
        if len(pla) > 0:
            pla = pla[0]
            pla = re.sub(r"sl ?\.? ?", "", pla)
            pla = pla.split(" ")
            pla = ".".join(pla)
            pla = re.sub(r"\.{2,}", ".", pla)
            return pla
        else:
            saveLogD("Could not get the SL", str(for_ref))
            pla = None

        tpPattern = [[r"sl\.? \d+\.\d+|sl\.? open", r"sl\.? "],  # sl 1972.00 or sl. 1972.00
                     [r"sl\.? \d+|sl\.? open", r"sl\.? "],  # sl 1972 or sl. 1972
                     # sl 1972.00 or sl. 1972.00
                     [r"sl\d+\.\d+|slopen", r"sl"],
                     [r"sl\d+|slopen", r"sl"]
                     ]
        return getRealValues(txt, tpPattern)
    except Exception as err:
        saveFailedExe("getSL in support", "getSL", str(err), for_ref)


async def getSignal(typ, txt):
    for_ref = txt
    try:
        rawD = txt
        saveLogD("getSignal "+str(date.today())+".txt", str(txt), "a")
        saveLogD("getSignal "+str(date.today())+".txt", txt +
                 "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n", "a")
        slstring = ""
        sl = ""
        tp = []
        tpstring = []
        entry = []
        symbolstring = "None"
        sig = dict()
        sig.update({'market execution': typ})
        while lastTPPosition(txt) != -1 or lastSLPosition(txt) != -1:
            if lastTPPosition(txt) < lastSLPosition(txt):
                slstring = substring(txt, lastSLPosition(txt), len(txt))
                slstring = removeUrl(slstring)
                # slstring = signalCleanUp(slstring)
                slstring = getSL(slstring)
                sl = slstring
                txt = substring(txt, 0, lastSLPosition(txt))
            elif lastTPPosition(txt) > lastSLPosition(txt):
                k = substring(txt, lastTPPosition(txt), len(txt))
                k = removeUrl(k)
                chars = ["=", ",", "@", "_", "-", "at", "/", "(", ")", "  "]
                for x in chars:
                    k = replaceAll(k, x, " ")

                pla = re.findall(r"\d+\. \d+", k)
                for x in pla:
                    lo = x
                    lo = replaceAll(lo, " ", "")
                    k = replaceAll(k, x, lo)

                pla = re.findall(r"\d+\.\d+\.\d+", k)
                for x in pla:
                    lo = x
                    lo = lo.split(".")
                    lo = lo[0]+" "+lo[1]+"."+lo[2]
                    k = replaceAll(k, x, lo)
                k = re.sub(r"\d+%", " ", k)
                # k = re.sub(r"\.{2, }", " ", k)
                k = replaceAll(k, "  ", " ")
                tpstring.append(getTP(k))
                txt = substring(txt, 0, lastTPPosition(txt))

        txt = replaceAll(txt, "(", " ")
        txt = replaceAll(txt, ")", " ")
        txt = replaceAll(txt, "  ", " ")
        symbolstring = await getSymbol(txt)
        sig.update(symbolstring)
        global othName
        othName = symbolstring["OtherName"] if "OtherName" in symbolstring else othName
        txt = replaceAll(txt, othName.lower(), " ")
        txt = replaceAll(txt, "  ", " ")
        entry = getEntry(txt)
        if symbolstring["gotit"]:
            saveLogD("track", "track 1\n")
            sig.update({"symbol": symbolstring["symbol"]})
            saveLogD("track", str(sig)+"\n")
        sig.update({"entry": entry})
        sig.update({"sl": sl})
        sig.update({"tp": tpstring})
        # sig.update(symbolstring)
        if symbolstring['gotit']:
            saveLogD("symbols "+str(date.today())+".txt", "The original text is\n"+rawD +
                     "\nThe symbol is\n"+symbolstring["symbol"]+"\n\n\n", "a")
        return sig
    except Exception as err:
        saveFailedExe("getSignal in support", "getSignal", str(err), for_ref)


def notInterest(txt):
    for_ref = txt
    try:
        lis = ["for tp and sl", "link", "join", "vip", "pip", "+pip",
               "-pip", "hit", "don't", "becareful"]
        test = False
        for x in lis:
            if txt.find(x) != -1:
                test = True
                break
        return test
    except Exception as err:
        saveFailedExe("notInterest in support",
                      "notInterest", str(err), for_ref)


def getInfor(time, chatName, link, txt, id):
    for_ref = (time, chatName, link, txt, id)
    try:
        fileN = "All Messages "+str(date.today())+".txt"
        infor = ""
        if not ifLogFileExist(fileN):
            infor = inforTitles+"\n"
        txt = replaceAll(txt, "\n", " ")
        txt = replaceAll(txt, "  ", " ")
        pla = chatName+"\t"+str(id)+"\t"+txt+"\t"+str(time)+"\t"+str(link)+"\n"
        infor = infor+pla
        saveLogD(fileN, infor, "a")
    except Exception as err:
        saveFailedExe("getInfor in support", "getInfor", str(err), for_ref)


def saveSignal(header, row):
    for_ref = (header, row)
    try:
        tday = date.today()
        fName = "Signal "+str(tday)+".txt"
        fText = ""
        if not ifLogFileExist(fName):
            x = 0
            while x < len(header):
                t = fText+str(header[x])
                fText = t+"\t" if x != (len(header)) - 1 else t+"\n"
                x = x+1

        x = 0
        while x < len(row):
            f = str(row[x])
            f = replaceAll(f, "\n", " ")
            f = replaceAll(f, "\t", " ")
            f = replaceAll(f, "  ", " ")
            t = fText+str(f)
            fText = t+"\t" if x != (len(row) - 1) else t+"\n"
            x = x+1

        saveLogD(fName, fText, "a")
    except Exception as err:
        saveFailedExe("SaveSignal in support", "SaveSignal", str(err), for_ref)


async def analyzeText(message):
    for_ref = message
    try:
        txt = message.text

        sig = dict()
        txt = clean(txt, no_emoji=True)
        txt = replaceAll(txt, "\n", "````")
        txt = replaceAll(txt, "`````", "````")
        txt = removeUrl(txt)
        txt = replaceAll(txt, ":", " ")
        txt = replaceAll(txt, "*", " ")
        txt = replaceAll(txt, "#", " ")
        txt = removeUrl(txt)

        txt = replaceAll(txt, "  ", " ")
        msg = txt
        if inndexf(txt.split(" "), "buy") >= 0 or inndexf(txt.split(" "), "sell") >= 0 or inndexf(txt.split(" "), "close") >= 0:
            saveLogD("possible a signal", str(for_ref))
            kilo = ["close", "buy stop limit", "sell stop limit",
                    "buy limit", "sell limit", "buy stop", "sell stop", "buy", "sell"]
            for x in kilo:
                if txt.find(x) >= 0:
                    sig = await getSignal(x, txt)
                    if sig['sl'] is not None:
                        return await trade(sig)
        else:
            saveLogD("Not a signal", str(for_ref))
    except Exception as err:
        saveFailedExe("AnalyzeText in support",
                      "AnalyzeText", str(err), for_ref)
