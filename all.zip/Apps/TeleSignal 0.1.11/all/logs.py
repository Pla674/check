import os
from datetime import date
import datetime
from settings import *
import json

if os.path.isdir("logs") != True:
    os.mkdir("logs")


def saveLog(filename, txt, command='a'):
    try:
        savetxt(filename, txt, "logs", command)
    except Exception as err:
        saveLogD("saveLog in logs", str(err))


def savetxt(filename, txt, folder, command='a'):
    txt = str(txt)
    save_path = os.path.dirname(os.path.abspath(__file__))+"/"+folder
    file_name = filename.strip()+".txt"
    completeName = os.path.join(save_path, file_name)
    file1 = open(completeName, command)
    seperate_text = "---------------------------------------------------------------------------------------------------\n"
    file1.write(seperate_text + txt + "\n"+seperate_text)
    file1.close()


def saveLogD(filename, txt, command='a'):
    try:
        filename = filename.strip()
        filename = filename+" "+str(date.today())
        saveLog(filename, txt, command='a')
        saveLog("All "+str(date.today()), txt, command='a')
    except Exception as err:
        saveLogD("saveLogD in logs", str(err))


def failedExeWrapper(fun="", err="", inp=""):
    erm = f"function : is {str(fun)}.\n"
    erm = erm + "Received Arguments : "+str(inp)+".\n"
    erm = erm + "The error message is : "+str(err)+".\n"
    return erm


def saveFailedExe(filename, fun, txt, inp="", command='a', send_log=True):
    txt = str(txt)
    txt = str(datetime.datetime.now())+" : "+txt
    txt = failedExeWrapper(fun, txt, inp)
    if send_log:
        error_data.append(txt)
        saveSettings("All error messages.json", error_data)
    filename = filename.strip()
    filename = filename+" "+str(date.today())
    saveLog(filename, txt, command='a')
    saveLog("All Error "+str(date.today()), txt, command='a')


def ifLogFileExist(filename):
    try:
        return os.path.exists(os.path.dirname(os.path.abspath(__file__))+"/logs/"+filename)
    except Exception as err:
        saveLogD("ifLogFileExist in logs", str(err))


try:
    error_data = loadSettings("All error messages.json")
except json.decoder.JSONDecodeError:
    error_data = []
    saveSettings("All error messages.json", error_data)
except (FileNotFoundError, TypeError):
    error_data = []
    saveSettings("All error messages.json", error_data)
