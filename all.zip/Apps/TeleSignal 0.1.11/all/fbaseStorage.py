import re
import datetime
from fBaseConfig import *
from logs import *
from assign import *
# define storage
storage = firebase.storage()
current_dir = "./"

cloud_logs = ["All 2024-06-20.txt", "All 2024-06-21.txt", "All 2024-06-26.txt", "All Error 2024-06-20.txt", "All Error 2024-06-23.txt", "All Error 2024-06-26.txt", "AnalyzeText in support 2024-06-20.txt", "Could not get entry 2024-06-21.txt", "Could not get the SL 2024-06-20.txt", "Could not get the SL 2024-06-27.txt", "Couldn't get symbol 2024-06-20.txt", "Couldn't get symbol 2024-06-21.txt", "Failed to get tp 2024-06-20.txt", "Handle Failed results 2024-06-20.txt", "Not a signal 2024-06-20.txt", "Not a signal 2024-06-26.txt", "Re Version.txt 2024-06-20.txt", "Re Version.txt 2024-06-21.txt", "Shit 2024-06-20.txt", "Shit 2024-06-21.txt", "Trade Main in mt45 2024-06-20.txt", "Trade Main in mt45 2024-06-21.txt", "Trade Main in mt45 2024-06-27.txt", "getSignal 2024-06-20.txt 2024-06-20.txt", "getSignal 2024-06-21.txt 2024-06-21.txt", "getSignal 2024-06-23.txt 2024-06-23.txt", "getSignal 2024-06-27.txt 2024-06-27.txt", "getSignal in support 2024-06-20.txt", "getSignal in support 2024-06-21.txt", "ji.txt", "kilo.txt", "log.txt", "messagesHandler in run 2024-06-20.txt", "messagesHandler in run 2024-06-22.txt", "mt45 Errors 2024-06-20.txt", "mt45 Errors 2024-06-21.txt", "mt45 running error 2024-06-23 14:33:04.780339.txt", "mt45 running error 2024-06-23 14:33:07.203957.txt", "mt45 running error 2024-06-23 14:33:09.743246.txt", "mt45 running error 2024-06-23 19:31:16.096183.txt", "mt45 running error 2024-06-23 19:31:19.642105.txt", "mt45 running error 2024-06-23 19:31:22.094933.txt", "mt45 running error 2024-06-23 19:33:35.179309.txt", "mt45 running error 2024-06-23 19:33:37.645251.txt", "mt45 running error 2024-06-23 19:33:39.995147.txt", "mt45 running error 2024-06-23 19:36:34.518845.txt", "mt45 running error 2024-06-23 19:36:37.420882.txt", "mt45 running error 2024-06-23 19:36:39.849569.txt", "mt45 running error 2024-06-23 20:03:03.550124.txt", "mt45 running error 2024-06-23 20:03:06.060012.txt", "mt45 running error 2024-06-23 20:03:08.486532.txt", "mt45 running error 2024-06-23 21:51:14.577703.txt",
              "mt45 running error 2024-06-23 21:51:14.809393.txt", "mt45 running error 2024-06-23 21:51:21.837314.txt", "mt45 running error 2024-06-23 21:51:21.837584.txt", "mt45 running error 2024-06-23 21:51:23.866007.txt", "mt45 running error 2024-06-23 21:51:23.904979.txt", "mt45 running error 2024-06-23 21:51:25.765457.txt", "mt45 running error 2024-06-23 21:51:26.252300.txt", "mt45 running error 2024-06-23 21:51:26.252551.txt", "mt45 running error 2024-06-23 21:51:28.283167.txt", "mt45 running error 2024-06-23 21:51:28.325906.txt", "mt45 running error 2024-06-23 21:51:28.509076.txt", "mt45 running error 2024-06-23 21:51:28.687463.txt", "mt45 running error 2024-06-23 21:51:28.687691.txt", "mt45 running error 2024-06-23 21:51:30.715367.txt", "mt45 running error 2024-06-24 07:43:06.911444.txt", "mt45 running error 2024-06-24 15:36:56.290495.txt", "mt45 running error 2024-06-24 15:37:07.694486.txt", "mt45 running error 2024-06-24 15:37:11.044557.txt", "mt45 running error 2024-06-24 19:32:35.911953.txt", "mt45 running error 2024-06-24 19:32:37.094691.txt", "mt45 running error 2024-06-24 19:32:40.453260.txt", "mt45 running error 2024-06-24 19:32:41.070064.txt", "mt45 running error2024-06-23 14:17:44.410973.txt", "mt45 running error2024-06-23 14:17:55.337688.txt", "mt45 running error2024-06-23 14:17:57.804794.txt", "output 2024-06-20 07:38:12.txt", "output 2024-06-20 16:24:12.txt", "output.txt", "pla.txt", "possible a signal 2024-06-20.txt", "save_trade_results in handle_results 2024-06-20.txt", "save_trade_results in handle_results 2024-06-21.txt", "save_trade_results in handle_results 2024-06-22.txt", "send_as_log in run 2024-06-20.txt", "send_as_log in run 2024-06-23.txt", "send_as_log in run 2024-06-24.txt", "success entry.txt 2024-06-20.txt", "success entry.txt 2024-06-21.txt", "success entry.txt 2024-06-22.txt", "symbols 2024-06-20.txt 2024-06-20.txt", "symbols 2024-06-21.txt 2024-06-21.txt", "track 2024-06-20.txt", "track 2024-06-21.txt", "track 2024-06-22.txt", "upload_all_files in fbaseStorage 2024-06-23.txt"]


def download_logs():
    for x in cloud_logs:
        storage.child("logs/"+str(x)).download("./", "des/"+str(x)+"\n")


def upload_all_logs():
    try:
        upload_dir("logs", "./logs")
    except Exception as err:
        saveFailedExe("upload_all_logs in fbaseStorage",
                      "upload_all_logs", str(err), for_ref)


def upload_all_files(cloud_parent, directory=current_dir):
    for_ref = (cloud_parent, directory)
    try:
        for x in glob.glob(str(directory+"/*")):
            try:
                while x.find(current_dir) >= 0:
                    x = x.replace(current_dir, "")

                while x.find("//") >= 0:
                    x = x.replace("//", "/")
                if os.path.exists(x):
                    x = x
                elif os.path.exists(x+"\r"):
                    print("Son of a bitch")
                    x = x+"\r"
                else:
                    print("Nothing here man")
                    continue
                storage.child(x.strip("\r")).put(x)
                tody = str(datetime.date.today())
                old_file = re.findall(r"\b\d{4}-\d{2}-\d{2}\b", str(x))
                if len(old_file) > 0 and old_file[0] != tody:
                    os.remove(str(x))
            except IsADirectoryError:
                print("sure")
            except Exception as err:
                print("Fuck you too", err)
    except Exception as err:
        saveFailedExe("upload_all_files in fbaseStorage",
                      "upload_all_files", str(err), for_ref)


def upload_dir(cloud_parent, dir="./"):
    for_ref = (cloud_parent, dir)
    try:
        upload_all_files(cloud_parent, dir)
    except Exception as err:
        saveFailedExe("upload_dir in fbaseStorage",
                      "upload_dir", str(err), for_ref)


if "upload source code" not in kilo_input or kilo_input["upload source code"].lower() == "y":
    if "upload source code" not in kilo_input:
        kilo_input.update({"upload source code": input(
            "Do you want to upload your source code (y/n): ")})
    if kilo_input["upload source code"].lower() == "y":
        if os.path.exists("./all.zip"):
            os.remove("./all.zip")
        os.system(
            "zip -r all.zip *.py settings/ defaults/ *.txt *.sh *.bash *.json")
        storage.child("zip").child("all.zip").put("./all.zip")

if "download source code" not in kilo_input or kilo_input["download source code"].lower() == "y":
    if "download source code" not in kilo_input:
        kilo_input.update({"download source code": input(
            "Do you want to download your source code (y/n): ")})
    if kilo_input["download source code"].lower() == "y":
        if os.path.exists("./all.zip"):
            os.remove("./all.zip")
        storage.child("zip/all.zip").download("./", "all.zip")

upload_all_logs()
