import gspread
from google.oauth2.service_account import Credentials

scopes = ["https://www.googleapis.com/auth/spreadsheets"]
creds = Credentials.from_service_account_file(
    "crdntls.json", scopes=scopes)
client = gspread.authorize(creds)

sheet_id = "12HS8QobebZquXQTEzeUpxp2UJEYbTvg7kSsp9g6yUp4"
workbook = client.open_by_key(sheet_id)
