import math
from instruments import *
from settings import *
from dotenv import load_dotenv
from kschedule import *
from logs import *
from datetime import datetime, timedelta
from metaapi_cloud_sdk import MetaApi
import asyncio
import re
import os
import contextlib
# Note: for information on how to use this example code please read https://metaapi.cloud/docs/client/usingCodeExamples

metatrader_accounts = []

matatrader_accounts_info = []
con = []
try:
    unknown_symbols = loadSettings("Unknown Symbols.json")
except Exception:
    saveSettings("Unknown Symbols.json", {})

try:
    try:
        matatrader_accounts_info = loadSettings(
            "matatrader_accounts_info.json")
    except FileNotFoundError:
        MetaApi_token = True
        while MetaApi_token:
            token = dict()
            token.update(
                {"token": input("Please provide your MetaApi token: ")})
            token.update({"secret": []})
            secret = True
            while secret:
                jika = dict()
                jika.update(
                    {"key": input("Please provide your MetaApi secret: ")})
                jika.update({"symbols": []})
                if input("Does the account have a suffix (y/n)? ") == "y":
                    jika.update(
                        {"suffix": input("Please provide the suffix: ")})
                token["secret"].append(jika)
                secret = True if input(
                    "Do you want to add another secret under this MetaApi token (y/n)? ") == "y" else False
            matatrader_accounts_info.append(token)
            saveSettings("matatrader_accounts_info.json",
                         matatrader_accounts_info)
            MetaApi_token = True if input(
                "Do you want to add another MetaApi token (y/n)? ") == "y" else False
except Exception as err:
    saveFailedExe("init in mt45", "init", str(err), "")

load_dotenv()

accountId = ""


async def tooManyRequestsExceptionHandler(fd):
    fd = str(fd)
    fd = fd[fd.find(": Failed to subscribe"):]
    fd = fd.replace(": Failed to subscribe", "")
    fd = eval(fd)
    check_string = str(timeDifInSeconds(
        fd["metadata"]["recommendedRetryTime"]))
    check_string = math.ceil(float(check_string))
    saveLogD("tooManyRequestsExceptionHandler",
             "Sleep time in seconds : "+str(check_string))
    if check_string <= 5:
        return ["await asyncio.sleep(check_string)"]
    else:
        return ['scheduler.add_job(job, "date", run_date=datetime.now() + timedelta(seconds='+str(check_string)+'), max_instances=2)', 'return']


async def telegramAWaitOfXSecondsHandler(check_string):
    check_string = re.findall(r"A wait of \d+\S+", check_string)
    check_string = re.findall(r"A wait of \d+\S+", check_string[0])
    (r"\d+\S+", check_string[0])
    check_string = math.ceil(float(check_string[0]))
    saveLogD("telegramAWaitOfXSecondsHandler",
             "Sleep time in seconds : "+str(check_string))
    if check_string <= 5:
        return ["await asyncio.sleep(check_string)"]
    else:
        return ['scheduler.add_job(job, "date", run_date=datetime.now() + timedelta(seconds='+str(check_string)+'), max_instances=2)', 'return']


async def checkExecute(temp_log):
    if os.path.exists(temp_log):
        kilo_err = getError(temp_log)
        if str(kilo_err).find("TooManyRequestsException") > -1:
            c = await tooManyRequestsExceptionHandler(kilo_err)
            for u in c:
                eval(u)
            temp_log = createTempLog()
            return ["print('')", temp_log, c]

        if str(kilo_err).find("Telegram says") > -1:
            check_string = re.findall(
                r"A wait of \d+\S+ seconds", str(kilo_err))
            if len(check_string) > 0:
                c = await telegramAWaitOfXSecondsHandler(check_string[0])
                for u in c:
                    eval(u)
                temp_log = createTempLog()
                return ["print('')", temp_log, c]
        saveLog(temp_log.rstrip(".txt"), str(kilo_err))
        return ["break", temp_log, "print('')"]
    else:
        return ["print('')", temp_log, "print('')"]


def createTempLog():
    return "logs/mt45 running error " + str(datetime.now())+".txt"


def createDateTime(dt):
    datetym = dt.split("T")
    datels = datetym[0].split("-")
    tymls = datetym[1].split(":")
    secs = re.sub(r"[A-Za-z]$", "", tymls[2])
    secs = secs.split(".")
    tymls[2] = secs[0]
    tymls.append(secs[1])
    datels = list(map(lambda x: int(x), datels))
    tymls = list(map(lambda x: int(x), tymls))
    return datetime(datels[0], datels[1], datels[2], tymls[0], tymls[1], tymls[2], tymls[3])


def getError(file):
    with open(file, "r") as f:
        fd = f.read()
    return fd


def timeDifInSeconds(tym):
    nowty = datetime.now()
    thenTym = createDateTime(tym)
    return (thenTym - nowty).total_seconds()

# temp_log = "logs/jaba.txt"
# a, temp_log = asyncio.run(checkExecute(temp_log))


async def get_account_symbols(token, accountId):
    for_ref = (token, accountId)
    try:
        try:
            connection = await get_connection(token, accountId)

            # trade
            temp_log = createTempLog()
            for i in range(5):
                a, temp_log, c = await checkExecute(temp_log)
                eval(a)
                with open(temp_log, "w") as f:
                    with contextlib.redirect_stdout(f):
                        symbols = await connection.get_symbols()
                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                "code completed", "logs")
                        break

            unknown_symbols = loadSettings("Unknown Symbols.json")
            if str(token) in unknown_symbols:
                if str(accountId) in unknown_symbols[str(token)]:
                    current_symbols = unknown_symbols[str(
                        token)][str(accountId)]['symbols']
                    total_symbols = current_symbols + symbols
                    total_symbols = list(set(total_symbols))
                    unknown_symbols[str(
                        token)][str(accountId)].update({'symbols': total_symbols})
                else:
                    unknown_symbols[str(token)].update(
                        {str(accountId): {'symbols': symbols}})
            else:
                unknown_symbols.update(
                    {str(token): {str(accountId): {'symbols': symbols}}})
            saveSettings("Unknown Symbols.json", unknown_symbols)
            await find_new_instrument()
            return symbols
            if initial_state not in deployed_states:
                # undeploy account if it was undeployed
                print('Undeploying account')

                temp_log = createTempLog()
                for i in range(5):
                    a, temp_log, c = await checkExecute(temp_log)
                    eval(a)
                    with open(temp_log, "w") as f:
                        with contextlib.redirect_stdout(f):
                            await connection.close()
                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                    "code completed", "logs")
                            break

                temp_log = createTempLog()
                for i in range(5):
                    a, temp_log, c = await checkExecute(temp_log)
                    eval(a)
                    with open(temp_log, "w") as f:
                        with contextlib.redirect_stdout(f):
                            await account.undeploy()
                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                    "code completed", "logs")
                            break

        except Exception as err:
            print(api.format_error(err))
    except Exception as err:
        saveFailedExe("get_account_symbols in mt45",
                      "get_account_symbols", str(err), for_ref)


async def trade(trade_infor):
    for_ref = (trade_infor)
    try:
        trade_results_info = []
        if trade_infor['sl'] is None:
            trade_infor.update({"executed": False})
            trade_infor.update({"reason": "Stop loss is not set"})
            return trade_infor
        if trade_infor['sl'] == 'open':
            trade_infor.update({"executed": False})
            trade_infor.update({"reason": "Stop loss is open"})
            return trade_infor
        if 'accounts' not in trade_infor.keys():
            trade_infor.update({"executed": False})
            trade_infor.update({"reason": "No account for this symbol"})
            return trade_infor
        accountsk = trade_infor['accounts']['key']
        token = trade_infor['accounts']['token']
        symbol = trade_infor['accounts']['symbol']
        try:
            connection = await get_connection(token, accountsk)
            # trade
            sl = float(trade_infor['sl'])
            entry = trade_infor['entry']
            temp_log = createTempLog()
            for i in range(5):
                a, temp_log, c = await checkExecute(temp_log)
                eval(a)
                with open(temp_log, "w") as f:
                    with contextlib.redirect_stdout(f):
                        current_price = await connection.get_symbol_price(symbol=symbol)
                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                "code completed", "logs")
                        break

            connection.get_symbol_specification
            if entry != 'current price':
                entry = re.sub(r"\'|\[|\]|\s", "", entry)
                if entry.find(",") != -1:
                    entry = entry.split(",")
                    entry = list(map(lambda x: float(x), entry))
                    entry = list(map(float, entry))
                    entry = [float(x) for x in entry]
                    entry.sort()
                if trade_infor['market execution'].find(
                        'buy'):
                    work_with_price = current_price['ask']
                    if float(entry[1]) > work_with_price and float(entry[0]) > work_with_price:
                        entry = 'current price'
                    elif float(entry[0]) > work_with_price:
                        entry = float(entry[0])
                    elif float(entry[1]) < work_with_price:
                        entry = float(entry[1])
                elif trade_infor['market execution'].find(
                        'sell'):
                    work_with_price = current_price['bid']
                    if float(entry[1]) > work_with_price and float(entry[0]) > work_with_price:
                        entry = 'current price'
                    elif float(entry[0]) > work_with_price:
                        entry = float(entry[0])
                    elif float(entry[1]) < work_with_price:
                        entry = float(entry[1])
            tp = trade_infor['tp']
            temp_log = createTempLog()
            for i in range(5):
                a, temp_log, c = await checkExecute(temp_log)
                eval(a)
                with open(temp_log, "w") as f:
                    with contextlib.redirect_stdout(f):
                        symbol_info = await connection.get_symbol_specification(symbol)
                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                "code completed", "logs")
                        break

            temp_log = createTempLog()
            for i in range(5):
                a, temp_log, c = await checkExecute(temp_log)
                eval(a)
                with open(temp_log, "w") as f:
                    with contextlib.redirect_stdout(f):
                        account_infor = await connection.get_account_information()
                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                "code completed", "logs")
                        break

            account_balance = account_infor['balance']
            risk_percent = 1
            current_entry_price = current_price['bid'] if trade_infor['market execution'].find(
                'buy') == -1 else current_price['ask']
            riskpe_rcent = risk_percent / 100
            trade_infor.update({"current_entry_price": current_entry_price})
            slDistance = current_entry_price - \
                sl if current_entry_price > sl else sl - current_entry_price
            ticksize = symbol_info['tickSize']
            tickvalue = trade_infor['Tick Value'] if 'Tick Value' in trade_infor.keys(
            ) else -1
            lotstep = symbol_info['volumeStep']
            lot_size = symbol_info['minVolume'] if tickvalue == -1 else lot_size_calc(
                account_balance, riskpe_rcent, slDistance, ticksize, tickvalue, lotstep)
            trade_infor.update({'init_lot_size': lot_size})
            lot_size = symbol_info['minVolume'] if lot_size < symbol_info['minVolume'] else lot_size
            lot_size = symbol_info['maxVolume'] if lot_size > symbol_info['maxVolume'] else lot_size
            trade_infor.update({'lot_size': lot_size})
            comment = ''
            for x in tp:
                if x == 'open':
                    continue
                if x is None:
                    continue
                if sl is None:
                    continue
                try:
                    result = ""
                    if trade_infor['market execution'] == 'buy' and entry == 'current price':
                        temp_log = createTempLog()
                        for i in range(5):
                            a, temp_log, c = await checkExecute(temp_log)
                            eval(a)
                            with open(temp_log, "w") as f:
                                with contextlib.redirect_stdout(f):
                                    result = await connection.create_market_buy_order(symbol, lot_size, sl, float(x), {'comment': '', 'clientId': 'TE_'+"T"+'_7hyINWqAlE'})
                                    savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                            "code completed", "logs")
                                    break

                    elif trade_infor['market execution'] == 'sell' and entry == 'current price':
                        temp_log = createTempLog()
                        for i in range(5):
                            a, temp_log, c = await checkExecute(temp_log)
                            eval(a)
                            with open(temp_log, "w") as f:
                                with contextlib.redirect_stdout(f):
                                    result = await connection.create_market_sell_order(symbol, lot_size, sl, float(x), {'comment': comment, 'clientId': 'TE_'+"T"+'_7hyINWqAlE'})
                                    savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                            "code completed", "logs")
                                    break

                    elif trade_infor['market execution'] == 'buy stop limit':
                        temp_log = createTempLog()
                        for i in range(5):
                            a, temp_log, c = await checkExecute(temp_log)
                            eval(a)
                            with open(temp_log, "w") as f:
                                with contextlib.redirect_stdout(f):
                                    result = await connection.create_stop_limit_buy_order(symbol, lot_size, entry, sl, float(x), {'comment': comment, 'clientId': 'TE_'+"T"+'_7hyINWqAlE'})
                                    savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                            "code completed", "logs")
                                    break

                    elif trade_infor['market execution'] == 'sell stop limit':
                        temp_log = createTempLog()
                        for i in range(5):
                            a, temp_log, c = await checkExecute(temp_log)
                            eval(a)
                            with open(temp_log, "w") as f:
                                with contextlib.redirect_stdout(f):
                                    result = await connection.create_stop_limit_sell_order(symbol, lot_size, entry, sl, float(x), {'comment': comment, 'clientId': 'TE_'+"T"+'_7hyINWqAlE'})
                                    savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                            "code completed", "logs")
                                    break

                    elif trade_infor['market execution'] == 'buy stop':
                        temp_log = createTempLog()
                        for i in range(5):
                            a, temp_log, c = await checkExecute(temp_log)
                            eval(a)
                            with open(temp_log, "w") as f:
                                with contextlib.redirect_stdout(f):
                                    result = await connection.create_stop_buy_order(symbol, lot_size, entry, sl, float(x), {'comment': comment, 'clientId': 'TE_'+"T"+'_7hyINWqAlE'})
                                    savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                            "code completed", "logs")
                                    break

                    elif trade_infor['market execution'] == 'sell stop':
                        temp_log = createTempLog()
                        for i in range(5):
                            a, temp_log, c = await checkExecute(temp_log)
                            eval(a)
                            with open(temp_log, "w") as f:
                                with contextlib.redirect_stdout(f):
                                    result = await connection.create_stop_sell_order(symbol, lot_size, entry, sl, float(x), {'comment': comment, 'clientId': 'TE_'+"T"+'_7hyINWqAlE'})
                                    savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                            "code completed", "logs")
                                    break

                    elif trade_infor['market execution'] == 'buy limit' or (trade_infor['market execution'] == 'buy' and entry != 'current price'):
                        temp_log = createTempLog()
                        for i in range(5):
                            a, temp_log, c = await checkExecute(temp_log)
                            eval(a)
                            with open(temp_log, "w") as f:
                                with contextlib.redirect_stdout(f):
                                    result = await connection.create_limit_buy_order(symbol, lot_size, entry, sl, float(x), {'comment': comment, 'clientId': 'TE_'+"T"+'_7hyINWqAlE'})
                                    savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                            "code completed", "logs")
                                    break

                    elif trade_infor['market execution'] == 'sell limit' or (trade_infor['market execution'] == 'sell' and entry != 'current price'):
                        temp_log = createTempLog()
                        for i in range(5):
                            a, temp_log, c = await checkExecute(temp_log)
                            eval(a)
                            with open(temp_log, "w") as f:
                                with contextlib.redirect_stdout(f):
                                    result = await connection.create_limit_sell_order(symbol, lot_size, entry, sl, float(x), {'comment': comment, 'clientId': 'TE_'+"T"+'_7hyINWqAlE'})
                                    savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                            "code completed", "logs")
                                    break

                    # result = await connection.create_market_sell_order(symbol, 0.07, 0, 0, {'comment': 'comm', 'clientId': 'TE_'+"T"+'_7hyINWqAlE'})
                    if result != '':
                        print('Trade successful, result code is ' +
                              result['stringCode'])
                        trade_infor.update({"executed": True})
                        try:
                            temp_log = createTempLog()
                            for i in range(5):
                                a, temp_log, c = await checkExecute(temp_log)
                                eval(a)
                                with open(temp_log, "w") as f:
                                    with contextlib.redirect_stdout(f):
                                        trade_meta = await connection.get_position(result['positionId'])
                                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                                "code completed", "logs")
                                        break

                            trade_infor.update({"trade_meta": trade_meta})
                        except Exception as er:
                            trade_infor.update({"trade_meta": current_price['bid'] if trade_infor['market execution'].find(
                                'buy') == -1 else current_price['ask']})
                            saveFailedExe("Could not find trade in mt45", "trade",
                                          "The was an error when tring to get the position data for position : "+str(result['positionId']), for_ref)
                            saveFailedExe(
                                "Could not find trade in mt45", "Could not find trade in mt45", str(err), for_ref)

                        trade_infor.update({"results": result})
                        trade_infor.update({"results": result})
                        trade_infor.update({"tp now": x})
                        trade_infor.update(
                            {"meta_account_data": account_infor})
                        trade_results_info.append(trade_infor)
                except Exception as err:
                    saveFailedExe("Fail to execute in mt45",
                                  "Fail to execute", str(err), for_ref)
                    trade_infor.update({"executed": False})
                    trade_infor.update({"error": err})
                    trade_results_info.append(trade_infor)
                    saveFailedExe("Fail to execute in mt45",
                                  "Fail to execute", str(err), for_ref)
                    if str(api.format_error(err)['string_code']) == 'TRADE_RETCODE_INVALID_STOPS':
                        pass
                    else:
                        saveFailedExe("Could not place trade in mt45", "Could not place trade", str(
                            api.format_error(err)), for_ref)

            if initial_state not in deployed_states:
                # undeploy account if it was undeployed
                saveLogD('Undeploying account', 'Undeploying account')
                temp_log = createTempLog()
                for i in range(5):
                    a, temp_log, c = await checkExecute(temp_log)
                    eval(a)
                    with open(temp_log, "w") as f:
                        with contextlib.redirect_stdout(f):
                            await connection.close()
                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                    "code completed", "logs")
                            break

                temp_log = createTempLog()
                for i in range(5):
                    a, temp_log, c = await checkExecute(temp_log)
                    eval(a)
                    with open(temp_log, "w") as f:
                        with contextlib.redirect_stdout(f):
                            await account.undeploy()
                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                    "code completed", "logs")
                            break

        except Exception as err:
            saveFailedExe("Trade Main in mt45",
                          "Trade Main", str(err), for_ref)
            trade_infor.update({"executed": False})
            trade_infor.update({"error": err})
            trade_results_info.append(trade_infor)
            saveFailedExe("Trade Main in mt45", "Trade Main",
                          str(trade_infor), for_ref)
            saveFailedExe("Trade Main in mt45", "Trade Main",
                          str(api.format_error(err)), for_ref)
        return trade_results_info
    except Exception as err:
        saveFailedExe("trade in mt45", "Trade Main", str(err), for_ref)


def invalidStops(entry, current_price, trade_infor):
    for_ref = (entry, current_price, trade_infor)
    try:
        saveFailedExe("invalidStops in mt45", "invalidStops",
                      "The trade infor : "+str(trade_infor)+"\n", for_ref)
        saveFailedExe("invalidStops in mt45", "invalidStops",
                      "The entry is : "+str(entry)+"\n", for_ref)
        saveFailedExe("invalidStops in mt45", "invalidStops",
                      "The bid price is : "+str(current_price['bid'])+"\n", for_ref)
        saveFailedExe("invalidStops in mt45", "invalidStops",
                      "The ask price is : "+str(current_price['ask'])+"\n", for_ref)
    except Exception as err:
        saveFailedExe("invalidStops in mt45",
                      "invalidStops", str(err), for_ref)


def invalidPrice(entry, current_price, trade_infor):
    for_ref = (entry, current_price, trade_infor)
    try:
        saveFailedExe("invalidPrice in mt45", "invalidPrice",
                      "The entry is : "+str(entry)+"\n", for_ref)
        saveFailedExe("invalidPrice in mt45", "invalidPrice",
                      "The trade infor is : "+str(trade_infor)+"\n", for_ref)
        saveFailedExe("invalidPrice in mt45", "invalidPrice",
                      "The bid price is : "+str(current_price['bid'])+"\n", for_ref)
        saveFailedExe("invalidPrice in mt45", "invalidPrice",
                      "The ask price is : "+str(current_price['ask'])+"\n", for_ref)
    except Exception as err:
        saveFailedExe("invalidPrice in mt45",
                      "invalidPrice", str(err), for_ref)


def lot_size_calc(account_balance, riskpercent, slDistance, ticksize, tickvalue, lotstep):
    for_ref = (account_balance, riskpercent,
               slDistance, ticksize, tickvalue, lotstep)
    try:
        riskmoney = account_balance * riskpercent / 100
        moneylotstep = (slDistance / ticksize) * tickvalue * lotstep
        lots = (riskmoney / moneylotstep) * lotstep
        return lots
    except Exception as err:
        saveFailedExe("lot_size_calc in mt45",
                      "lot_size_calc", str(err), for_ref)


async def get_meta_accounts():
    for_ref = ""
    try:
        for x in matatrader_accounts_info:
            for y in x['secret']:
                if "symbols" in y.keys() and y['symbols'] != None:
                    continue
                temp_log = createTempLog()
                for i in range(5):
                    a, temp_log, c = await checkExecute(temp_log)
                    eval(a)
                    with open(temp_log, "w") as f:
                        with contextlib.redirect_stdout(f):
                            symbols = await get_account_symbols(x['token'], y['key'])
                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                    "code completed", "logs")
                            break

                y.update({"symbols": symbols})
        saveSettings("matatrader_accounts_info.json",
                     matatrader_accounts_info)
    except Exception as ex:
        saveFailedExe("get_meta_accounts in mt45",
                      "get_meta_accounts", str(ex), for_ref)


async def get_position_data():
    for_ref = ""
    try:
        all_running_trades = loadSettings("running trades.json")
        for x in all_running_trades:
            for y in all_running_trades[x]:
                try:
                    connection = await get_connection(x, y)
                    # trade
                    for j in all_running_trades[x][y]:
                        try:
                            temp_log = createTempLog()
                            for i in range(5):
                                a, temp_log, c = await checkExecute(temp_log)
                                eval(a)
                                with open(temp_log, "w") as f:
                                    with contextlib.redirect_stdout(f):
                                        update_position = await connection.get_position(j['value']['Ticket Number'])
                                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                                "code completed", "logs")
                                        break

                            j['value'].update({"Status": "running"})
                            j['value'].update(
                                {"Entry Price": update_position['openPrice']})
                            j['value'].update(
                                {"Market Execution": update_position['type'].replace("POSITION_TYPE_", "").lower()})
                            j['value'].update(
                                {"SL": update_position['stopLoss'] if 'stopLoss' in update_position else 0})
                            j['value'].update(
                                {"TP": update_position['takeProfit'] if 'takeProfit' in update_position else 0})
                            j['value'].update(
                                {"Profits": update_position['profit']})
                            j['value'].update(
                                {"Used Lot Size": update_position['volume']})
                            j['value'].update(
                                {'Win or Loss': "lossing" if update_position['profit'] <= 0 else "winning"})
                            tick_value = loadSettings("tick value.json")
                            tick_value.update(
                                {update_position['symbol']: update_position['currentTickValue']})
                        except Exception as er:
                            try:
                                temp_log = createTempLog()
                                for i in range(5):
                                    a, temp_log, c = await checkExecute(temp_log)
                                    eval(a)
                                    with open(temp_log, "w") as f:
                                        with contextlib.redirect_stdout(f):
                                            update_position = await connection.get_history_orders_by_position(j['value']['Ticket Number'])
                                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                                    "code completed", "logs")
                                            break

                                if len(update_position['historyOrders']) > 0:
                                    j['value'].update({"Status": "complete"})
                                    j['value'].update(
                                        {"Market Execution": update_position['historyOrders'][0]['type'].replace("ORDER_TYPE_", "").lower()})
                                    j['value'].update(
                                        {"SL": update_position['historyOrders'][0]['stopLoss']})
                                    j['value'].update(
                                        {"TP": update_position['historyOrders'][0]['takeProfit']})
                                    j['value'].update(
                                        {"Used Lot Size": update_position['historyOrders'][0]['volume']})
                                    temp_log = createTempLog()
                                    for i in range(5):
                                        a, temp_log, c = await checkExecute(temp_log)
                                        eval(a)
                                        with open(temp_log, "w") as f:
                                            with contextlib.redirect_stdout(f):
                                                update_position = await connection.get_deals_by_position(j['value']['Ticket Number'])
                                                savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                                        "code completed", "logs")
                                                break

                                    j['value'].update(
                                        {"Profits": update_position['deals'][1]['profit']})
                                    j['value'].update(
                                        {"Win or Loss": "losing" if update_position['deals'][1]['profit'] <= 0 else "winning"})
                                    j['value'].update(
                                        {"Entry Price": update_position['deals'][0]['price']})
                                else:
                                    try:
                                        temp_log = createTempLog()
                                        for i in range(5):
                                            a, temp_log, c = await checkExecute(temp_log)
                                            eval(a)
                                            with open(temp_log, "w") as f:
                                                with contextlib.redirect_stdout(f):
                                                    update_position = await connection.get_order(j['value']['Ticket Number'])
                                                    savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                                            "code completed", "logs")
                                                    break

                                        j['value'].update(
                                            {'Market Execution': update_position['type'].replace("ORDER_TYPE_", "").replace("_", " ").lower()})
                                        j['value'].update(
                                            {'Current Lot Size': update_position['currentVolume']})
                                        j['value'].update(
                                            {'Entry Price': update_position['openPrice']})
                                        j['value'].update(
                                            {'TP': update_position['takeProfit'] if 'takeProfit' in update_position else 0})
                                        j['value'].update(
                                            {'SL': update_position['stopLoss'] if 'stopLoss' in update_position else 0})
                                        j['value'].update({'Status': 'placed'})
                                    except Exception as err:
                                        if str(err) == "Order with specified id not found":
                                            j['value'].update(
                                                {'Status': False})
                                        # else:
                                        saveFailedExe("Fail to get Order in get position data in mt45",
                                                      "Fail to get Order in get position data", str(err), for_ref)
                            except Exception as err:
                                print(err)
                                temp_log = createTempLog()
                                for i in range(5):
                                    a, temp_log, c = await checkExecute(temp_log)
                                    eval(a)
                                    with open(temp_log, "w") as f:
                                        with contextlib.redirect_stdout(f):
                                            update_position = await connection.get_deals_by_position(j['value']['Ticket Number'])
                                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                                    "code completed", "logs")
                                            break

                except Exception as err:
                    print(api.format_error(err))
        saveSettings("running trades.json", all_running_trades)
    except Exception as err:
        saveFailedExe("get_position_data in mt45",
                      "get_position_data", str(err), for_ref)

# asyncio.run(get_position_data())


async def get_broker_name(token, accountId):
    for_ref = (token, accountId)
    try:
        try:
            connection = await get_connection(token, accountId)

            # trade
            temp_log = createTempLog()
            for i in range(5):
                a, temp_log, c = await checkExecute(temp_log)
                eval(a)
                with open(temp_log, "w") as f:
                    with contextlib.redirect_stdout(f):
                        account_infor = await connection.get_account_information()
                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                "code completed", "logs")
                        print(account_infor['broker'])
                        return account_infor['broker']

            if initial_state not in deployed_states:
                # undeploy account if it was undeployed
                print('Undeploying account')
                temp_log = createTempLog()
                for i in range(5):
                    a, temp_log, c = await checkExecute(temp_log)
                    eval(a)
                    with open(temp_log, "w") as f:
                        with contextlib.redirect_stdout(f):
                            await connection.close()
                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                    "code completed", "logs")
                            break

                temp_log = createTempLog()
                for i in range(5):
                    a, temp_log, c = await checkExecute(temp_log)
                    eval(a)
                    with open(temp_log, "w") as f:
                        with contextlib.redirect_stdout(f):
                            await account.undeploy()
                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                    "code completed", "logs")
                            break

        except Exception as err:
            print(api.format_error(err))
    except Exception as err:
        saveFailedExe("get_account_symbols in mt45",
                      "get_account_symbols", str(err), for_ref)


async def get_connection(token, accountId):
    global con
    for i in con:
        if token == i["token"] and accountId == i["account_id"]:
            return i["connection"]

    try:
        api = MetaApi(token)
        try:
            temp_log = createTempLog()
            for i in range(5):
                a, temp_log, c = await checkExecute(temp_log)
                print(a)
                eval(a)
                with open(temp_log, "w") as f:
                    with contextlib.redirect_stdout(f):
                        account = await api.metatrader_account_api.get_account(accountId)
                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                "code completed", "logs")
                        break

            initial_state = account.state
            deployed_states = ['DEPLOYING', 'DEPLOYED']

            if initial_state not in deployed_states:
                temp_log = createTempLog()
                for i in range(5):
                    a, temp_log, c = await checkExecute(temp_log)
                    eval(a)
                    with open(temp_log, "w") as f:
                        with contextlib.redirect_stdout(f):
                            await account.deploy()
                            savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                    "code completed", "logs")
                            break

            temp_log = createTempLog()
            for i in range(5):
                a, temp_log, c = await checkExecute(temp_log)
                eval(a)
                with open(temp_log, "w") as f:
                    with contextlib.redirect_stdout(f):
                        await account.wait_connected()
                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                "code completed", "logs")
                        break

            # connect to MetaApi API
            connection = account.get_rpc_connection()
            temp_log = createTempLog()
            for i in range(5):
                a, temp_log, c = await checkExecute(temp_log)
                eval(a)
                with open(temp_log, "w") as f:
                    with contextlib.redirect_stdout(f):
                        await connection.connect()
                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                "code completed", "logs")
                        break

            temp_log = createTempLog()
            for i in range(5):
                a, temp_log, c = await checkExecute(temp_log)
                eval(a)
                with open(temp_log, "w") as f:
                    with contextlib.redirect_stdout(f):
                        await connection.wait_synchronized()
                        savetxt(temp_log.rstrip(".txt").lstrip("logs/"),
                                "code completed", "logs")
                        break

            new_con = {"token": token, "account_id": accountId,
                       "connection": connection}
            con.append(new_con)
            return connection
        except Exception as err:
            print(err)
    except Exception as er:
        print(err)


async def mt_rerun(token, accountId):
    try:
        await sha(await get_connection(token, accountId))
    except Exception as er:
        print(err)
