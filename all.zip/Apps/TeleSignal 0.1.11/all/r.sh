nowk="logs/output "`date +"%F %H-%M-%S"`".txt"
python run.py 'settings/actions.json' |tee "${nowk}"