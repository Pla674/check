from fBaseConfig import *

db = firebase.database()
# try:
#     new_value = str(max(list(map(lambda x: int(x), list(
#         db.child("Complete Trades").shallow().get().val())))) + 1)
# except Exception as g:
#     new_value = "0"
# print(new_value)

# data = db.child("Running Trades").get()

# for x in data:
#     print(x.key())
