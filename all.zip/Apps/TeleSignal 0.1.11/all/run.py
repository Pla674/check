# kilo
from kschedule import *
from handle_results import *
from support import analyzeText
from logs import *
from login import *

phone_number = ""

if os.path.exists("settings/text_chunks.json"):
    text_chunks = loadSettings("text_chunks.json")
else:
    text_chunks = []
    saveSettings("text_chunks.json", text_chunks)

send_wait = 0


async def send_as_log():
    try:
        for t in text_chunks:
            send_txt = True
            while send_txt:
                try:
                    rtemp_log = createTempLog()
                    for i in range(5):
                        a, rtemp_log = await checkExecute(rtemp_log)
                        eval(a)
                        with open(rtemp_log, "w") as f:
                            with contextlib.redirect_stdout(f):
                                await app.send_message("me", str(t))
                                savetxt(rtemp_log.rstrip(".txt").lstrip("logs/"),
                                        "code completed", "logs")
                    if t in text_chunks:
                        text_chunks.remove(t)
                except Exception as err:
                    new_err = re.findall(r"a wait of \d+\S seconds", str(err))
                    if len(new_err) > 0:
                        new_err = new_err[0]
                        new_err = re.findall(r"\b\d+\b", new_err)
                        send_wait = int(new_err[0])
                        asyncio.sleep(send_wait)
                    else:
                        send_txt = False
                        saveFailedExe("send_as_log in run", "send_as_log", str(
                            err), t, send_log=False)
    except Exception as err:
        saveFailedExe("send_as_log in run", "send_as_log",
                      str(err), t)


async def job():
    for_ref = ""
    try:
        # await sort_trades()
        error_data = loadSettings("All error messages.json")
        for x in error_data:
            max_len = 4000
            txt = x
            while len(txt) > max_len:
                text_chunks.append(txt[0:max_len])
                txt = txt[max_len:]
            text_chunks.append(txt)
            error_data.remove(x)
        saveSettings("All error messages.json", error_data)
    except Exception as err:
        print("The was an error : ", str(err))
        saveFailedExe("job in run", "job", str(err), for_ref)


scheduler.add_job(job, "interval", seconds=5, max_instances=2)
scheduler.add_job(send_as_log, "interval", minutes=1, max_instances=2)
scheduler.add_job(upload_all_logs, 'cron', hour=1, max_instances=2)


@app.on_message()
async def my_handler(client, message):
    for_ref = (client, message)
    try:
        await messagesHandler(message)
    except Exception as err:
        saveFailedExe("on_message in run", "on_message", str(err), for_ref)


async def messagesHandler(message):
    for_ref = message
    try:
        trade_data = await analyzeText(message)
        global phone_number
        if phone_number == "":
            phone_number = str((await app.get_me()).phone_number)
            print("Please kindly note the number used",
                  "\n", "Phone Number : ", phone_number)
        for h in trade_data:
            save_trade_results(
                {"message": message, "phone_number": phone_number, "trade_data": h})
    except Exception as err:
        saveFailedExe("messagesHandler in run",
                      "messagesHandler", str(err), for_ref)

scheduler.start()
app.run()
