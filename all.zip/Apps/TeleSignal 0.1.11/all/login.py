from random import randint
from pyrogram import Client
from dotenv import load_dotenv
import os

load_dotenv()

api_id = os.getenv("TELE_API_ID")
api_hash = os.getenv("TELE_API_HASH")
app = Client("my_account", api_id, api_hash)
