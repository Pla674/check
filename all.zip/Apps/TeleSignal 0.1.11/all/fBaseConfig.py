import os
import glob
import pyrebase

firebaseConfig = {
    "apiKey": "AIzaSyBL4hckTVhhCOi-8atdMW4R661d_BmeSqI",
    "authDomain": "telesignal-283f3.firebaseapp.com",
    "databaseURL": "https://telesignal-283f3-default-rtdb.firebaseio.com",
    "projectId": "telesignal-283f3",
    "storageBucket": "telesignal-283f3.appspot.com",
    "messagingSenderId": "184852339337",
    "appId": "1:184852339337:web:295430b5ac6c9d38ffc458",
    "measurementId": "G-FGC9HJ56T5"
}

firebase = pyrebase.initialize_app(firebaseConfig)
