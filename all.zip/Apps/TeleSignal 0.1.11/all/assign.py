import sys
from settings import *

kilo_input = sys.argv[1] if len(sys.argv) >= 2 else {}
if kilo_input != {} and sys.argv[1].find(".json") > -1:
    print("Input is : ", sys.argv)
    if sys.argv[1].find("/") == -1:
        kilo_input = loadSettings(kilo_input)
    else:
        kilo_input = kilo_input.rstrip("/")
        folderD = kilo_input.rfind("/")
        if folderD > -1:
            try:
                kilo_input = loadSettings(kilo_input[folderD:].strip("/"), kilo_input[0:folderD].rstrip(
                    "/"))
            except FileNotFoundError:
                print(
                    f"Sorry but file {kilo_input} was not found, you will have to provide details manual.")
                kilo_input = {}
elif kilo_input != {}:
    kilo_input = eval(sys.argv[1]) if len(sys.argv) >= 2 else {}

if type(kilo_input) == list and kilo_input != {}:
    if len(kilo_input) == 2:
        temp = {}
        temp.update({"download source code": kilo_input[0]})
        temp.update({"upload source code": kilo_input[1]})
        kilo_input = temp
    else:
        exit()

if kilo_input != {}:
    saveSettings("actions.json", kilo_input)
