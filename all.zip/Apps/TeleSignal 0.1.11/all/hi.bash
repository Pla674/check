apt-get update
python -m pip install huggingface_hub
pip install --upgrade pip
pip install -U pyrogram tgcrypto
pip install unidecode
pip install clean-text
pip install python-dotenv
pip install pyrebase4
pip install metaapi-cloud-sdk
pip install googletrans
pip install apscheduler
pip install google-api-python-client google-auth-httplib2 google-auth-oauthlib gspread
pip install pipreqs
pipreqs --force
apt update
apt install git-lfs
git lfs --version
huggingface-cli login
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
git remote add space https://huggingface.co/spaces/Nudo674/TeleSignal
git add .
git commit -m "Initial commit"
git push --forc space maine