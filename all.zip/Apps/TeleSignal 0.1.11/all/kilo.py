from logs import *
import asyncio
from pyrogram import Client
from dotenv import load_dotenv
import os

load_dotenv()

api_id = os.getenv("TELE_API_ID")
api_hash = os.getenv("TELE_API_HASH")


async def main():
    async with Client("my_account", api_id, api_hash) as app:
        await app.send_message("me", "Greetings from **Pyrogram**!")


asyncio.run(main())
