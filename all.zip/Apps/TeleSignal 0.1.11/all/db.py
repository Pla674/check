# pip install dropbox
import os
import dropbox
import dropbox.files
import glob
import stone.backends.python_rsrc
import dropbox.stone_validators
import re
from logs import *

db_token = "sl.B4jUVtDOxMhnBz7b1y92IE4r_BeKnDq60Y6JAuVav4TJXfoccHcvtZqHCBudG42Bj363O4KlBq0GI_uTBxfadTfUJ8f6fT9zJ9U9QXA1VnQ6AO3_aji5F_cUbkNul88gQU7xMXWlDnNM"

dbx = dropbox.Dropbox(db_token)
current_path = os.path.dirname(os.path.abspath(__file__))
all_files = []
file_name = "all.zip"
with open(file_name, 'rb') as f:
    dbx.files_upload(f.read(), "/all.zip",
                     mode=dropbox.files.WriteMode('overwrite'))
# def upload_file(file_name, dropbox_dir):
#     try:
#         with open(file_name, 'rb') as f:
#             dbx.files_upload(f.read(), dropbox_dir,
#                              mode=dropbox.files.WriteMode('overwrite'))
#     except Exception as err:
#         saveFailedExe("kupload_all_files in db", str(err))


# def upload_all_files(directory=""):
#     try:
#         print("Fuck 6 : ", directory)
#         for x in glob.glob(str(current_path+directory+"/*")):
#             print("Fuck 5 : ", x)
#             x = x.replace(str(current_path)+"/", "")
#             print("Fuck 4 : ", x)
#             if os.path.isdir(x):
#                 print("Fuck 3 : ", os.path.isdir(x))
#                 ki = "" if directory == "" else directory+"/"
#                 print("Fuck 2 : ", ki)
#                 ki = ki+str(x)
#                 print("Fuck : ", ki)
#                 upload_all_files(ki)
#             else:
#                 upload_file(x, "/"+x)

#         try:
#             dir_list = os.listdir(directory)
#         except FileNotFoundError:
#             print("Directory not found : ", directory)
#             dir_list = ""

#         if dir_list != "":
#             for x in os.listdir(directory):
#                 print("Directory : ", directory)
#                 print("X : ", x)
#                 print("Folders : ", directory+"/"+x)
#                 upload_all_files(directory+"/"+x)
#     except Exception as err:
#         saveFailedExe("upload_all_files in db", str(err))


# # upload_all_files()
# # upload_file("logs/test symbol.txt", "/logs/test symbol.txt")

# def kupload_all_files(dir="."):
#     try:
#         for x in os.listdir(dir):
#             if os.path.isdir(x):
#                 kupload_all_files(dir+"/"+x)
#             else:
#                 try:
#                     file = dir+"/"+x
#                     des = file
#                     des = re.sub(r"^.", "", des)
#                     upload_file(file, des)
#                 except IsADirectoryError:
#                     kupload_all_files(dir+"/"+x)
#                 except stone.backends.python_rsrc.stone_validators.ValidationError as ve:
#                     print(ve)
#     except Exception as err:
#         saveFailedExe("kupload_all_files in db", str(err))


# kupload_all_files()
