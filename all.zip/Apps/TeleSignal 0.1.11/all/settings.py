import json
import os

if os.path.isdir("settings") != True:
    os.mkdir("settings")


def loadSettings(filename, location="settings"):
    try:
        with open(location+"/"+filename, "r") as f:
            return json.load(f)
    except json.decoder.JSONDecodeError:
        raise json.decoder.JSONDecodeError
    except FileNotFoundError as err:
        raise FileNotFoundError("Settings file not found")


def saveSettings(filename, settings, location="settings"):
    with open(location+"/"+filename, "w") as f:
        json.dump(settings, f, indent=2)
