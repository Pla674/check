from fBaseDB import *
from fbaseStorage import *
from settings import *
from logs import *


def save_trades(new_data, trade_table):
    for_ref = (new_data, trade_table)
    try:
        try:
            received = db.child(trade_table).get().val()
            received = [] if received == None else received
            for x in new_data:
                if x not in received:
                    received.append(x)
            db.child(trade_table).set(received)
        except Exception as e:
            print(str(e))
    except Exception as err:
        saveFailedExe("save_trades in fbase", "save_trades", str(err), for_ref)


def save_complete_trade(new_data):
    for_ref = new_data
    try:
        try:
            new_value = str(max(list(map(lambda x: int(x), list(
                db.child("Complete Trades").shallow().get().val())))) + 1)
        except Exception as g:
            new_value = "0"
        db.child("Complete Trades").child(new_value).set(new_data)
    except Exception as err:
        saveFailedExe("save_complete_trade in fbase",
                      "save_complete_trade", str(err), for_ref)


def save_running_trade(raw_data):
    for_ref = raw_data
    try:
        new_data = []
        for x in raw_data:
            new_data.append(x['value'])
        db.child("Running Trades").set(new_data)
    except Exception as err:
        saveFailedExe("save_running_trade in fbase",
                      "save_running_trade", str(err), for_ref)
