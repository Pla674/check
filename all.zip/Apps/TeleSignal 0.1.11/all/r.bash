nowk="logs/output "`date +"%F %H:%M:%S"`".txt"
python run.py ${nowk} |tee "${nowk}"