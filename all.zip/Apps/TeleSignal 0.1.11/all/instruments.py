from mt45 import metatrader_accounts, get_meta_accounts, matatrader_accounts_info, get_account_symbols, get_broker_name
from settings import *
from logs import *
import json
import os
from random import randint
import asyncio
import re


accs = 0
instruments = ""

try:
    not_used_instruments = loadSettings("not used instruments.json")
except FileNotFoundError:
    not_used_instruments = loadSettings("all instruments.json")
    saveSettings("not used instruments.json", not_used_instruments)
except json.decoder.JSONDecodeError:
    not_used_instruments = loadSettings("all instruments.json")
    saveSettings("not used instruments.json", not_used_instruments)
except Exception as err:
    saveFailedExe("init in instruments", "init", str(err), "")

try:
    instrument_extra = loadSettings("instrument_extra.json")
except FileNotFoundError:
    instrument_extra = {}
    saveSettings("instrument_extra.json", instrument_extra)
except json.decoder.JSONDecodeError:
    instrument_extra = {}
    saveSettings("instrument_extra.json", instrument_extra)
except Exception as err:
    saveFailedExe("init in instruments", "init", str(err), "")

try:
    instruments = loadSettings("mostly used instruments.json")
except FileNotFoundError:
    instruments = {}
    saveSettings("mostly used instruments.json", instruments)
except json.decoder.JSONDecodeError:
    instruments = {}
    saveSettings("mostly used instruments.json", instruments)
except Exception as err:
    saveFailedExe("init in instruments", "init", str(err), "")


def get_instruments_extra():
    for_ref = ""
    try:
        return loadSettings("instrument_extra.json")
    except Exception as err:
        saveFailedExe("get_instruments_extra in instruments",
                      "get_instruments_extra", str(err), for_ref)


def save_instruments_tick_value(input):
    for_ref = input
    try:
        instrument_extra = get_instruments_extra()
        if str(input["symbol"]) in instrument_extra:
            instrument_extra[str(input["symbol"])].update(
                {"tick value": input['tick value']})
        else:
            instrument_extra.update(
                {str(input["symbol"]): {"tick value": input['tick value']}})
        saveSettings("instrument_extra.json", instrument_extra)
    except Exception as err:
        saveFailedExe("save_instruments_tick_value in instruments",
                      "save_instruments_tick_value", str(err), for_ref)


async def saveInstrument(data):
    for_ref = data
    try:
        if len(matatrader_accounts_info) == 0:
            trade_infor.update({"executed": False})
            trade_infor.update({"reason": "No MetaApi token"})
            return trade_infor

        if matatrader_accounts_info[0]['secret'][0]['key'] == '':
            trade_infor.update({"executed": False})
            trade_infor.update({"reason": "No MetaApi secret"})
            return trade_infor

        if "symbols" in matatrader_accounts_info[0]['secret'][0]:
            await get_meta_accounts()

        if len(matatrader_accounts_info[0]['secret'][0]['symbols']) == 0:
            await get_meta_accounts()

        data = data.casefold()
        j = data
        instruments = loadSettings("mostly used instruments.json")
        for x in instruments.keys():
            for k in instruments[x]:
                y = k["OtherName"].casefold()
                if k['OtherName'].casefold() == data.casefold():
                    data = k
                    instruments[x].remove(data)
                    if "accounts" not in data or len(data['accounts']) == 0:
                        data.update({"accounts": await get_metatrader_account(data['symbol'])})
                    new_key = str(int(x) + 1)
                    if new_key in instruments.keys():
                        instruments[new_key].append(data)
                        saveSettings(
                            "mostly used instruments.json", instruments)
                        return data
                    else:
                        temp_dict = {new_key: [data]}
                        instruments = {**temp_dict, **instruments}
                        saveSettings(
                            "mostly used instruments.json", instruments)
                        return data

        # check if symbol is in not_used_instruments
        for d in not_used_instruments:
            if d['OtherName'].casefold() == data.casefold():
                data = d
                not_used_instruments.remove(data)
                saveSettings("not used instruments.json", not_used_instruments)
                break

        if "1" in instruments.keys():
            if type(data) is dict:
                if "accounts" not in data or len(data['accounts']) == 0:
                    data.update({"accounts": await get_metatrader_account(data['symbol'])})
                instruments["1"].append(data)
                saveSettings("mostly used instruments.json", instruments)
                return data
        else:
            if type(data) is dict:
                if "accounts" not in data or len(data['accounts']) == 0:
                    data.update({"accounts": await get_metatrader_account(data['symbol'])})
                instruments.update({"1": [data]})
                saveSettings("mostly used instruments.json", instruments)
                return data

        return False
    except Exception as err:
        saveFailedExe("get_metatrader_account in instruments",
                      "get_metatrader_account", str(err), for_ref)


pairs = loadSettings("all instruments.json")
lenth = len(pairs)


async def get_metatrader_account(symbol):
    for_ref = symbol
    try:
        # loop through all MetaApi accounts to find the one that has the symbol
        for x in matatrader_accounts_info:
            # loop though all metatrader accounts in MetaApi
            for y in x['secret']:
                if "symbols" not in y.keys() or len(y["symbols"]) == 0:
                    symbols = await get_account_symbols(x['token'], y['key'])
                    y.update({"symbols": symbols})
                    saveSettings("matatrader_accounts_info.json",
                                 matatrader_accounts_info)
                suffix = list(y['suffix']) if 'suffix' in y else []
                suffix = list(map(lambda x: symbol + x, suffix))
                suffix = [symbol] + suffix
                for z in suffix:
                    if z in y['symbols']:
                        return {"token": x['token'], "key": y['key'], "symbol": z}
        return False
    except Exception as err:
        saveFailedExe("get_metatrader_account in instruments",
                      "get_metatrader_account", str(err), for_ref)


async def find_new_instrument():
    try:
        un_symbols = loadSettings("Unknown Symbols.json")
    except Exception as err:
        return

    un_symbols_collection = []

    all_sym = loadSettings("all instruments.json")
    all_sym_other = []
    for x in all_sym:
        all_sym_other.append(x["OtherName"])
    acc = loadSettings("matatrader_accounts_info.json")
    for x in acc:
        pass  # print(x['token'])

    gi = {}
    for x in un_symbols:
        for j in un_symbols[x]:
            print(await get_broker_name(x, j))
            for k in un_symbols[x][j]:
                if "suffix" not in k:
                    for a in acc:
                        if x == a['token']:
                            for b in a["secret"]:
                                if b["key"] == j:
                                    if "suffix" in b:
                                        gi = {"suffix": b["suffix"]}
                                    else:
                                        gi = {"suffix": ""}
            un_symbols[x][j].update(gi)
    saveSettings("Unknown Symbols.json", un_symbols)
    sym_without_suf = []
    for x in un_symbols:
        for j in un_symbols[x]:
            suffix = un_symbols[x][j]["suffix"]
            suffix = suffix.split(",")
            jika = "("
            for l in suffix:
                jika = jika+re.escape(l)+"|"
            jika.strip("|")
            suffix = jika+")$"
            for y in un_symbols[x][j]["symbols"]:
                sym_without_suf.append(re.sub(r""+suffix+"", "", y))
                # print(un_symbols[x][j]["suffix"])
    sym_without_suf = list(set(sym_without_suf))
    for x in sym_without_suf:
        if x not in all_sym_other:
            un_symbols_collection.append({"OtherName": x, "approved": False, "symbol": x, "market": "", "length": (
                len(x)), "fullName": "", "tick value": "", "Markets": ""})
    saveSettings("Sorted Unknown Symbols.json", un_symbols_collection)
